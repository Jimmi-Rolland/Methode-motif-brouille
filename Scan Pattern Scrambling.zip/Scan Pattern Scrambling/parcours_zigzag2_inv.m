function res = parcours_zigzag2_inv(V)
   % a = [1 2 3 4;5 6 7 8; 9 10 11 12;13 14 15 16;17 18 19 20;21 22 23 24]
   % b = [1 2 3 4 5 6;1 2 3 4 5 6;1 2 3 4 5 6;1 2 3 4 5 6]
   %  c = [1 2 3 4 5;6 7 8 9 10;11 12 13 14 15;16 17 18 19 20]

res = V;
[m,n,k]=size(V);
b=(1:m)'*ones(1,n);
a=ones(m,1)*(1:n);
A=a+b-1;
B=a-b;
C=(A.^2+(-1).^A.*B+1);
[C,I]=sort(C(:));

if( k == 3)
     %   disp('repetition');
        p=1;    
        for i = 1:m
            for j = 1:n
                i_p = mod(I(p)-1,m);
                j_p = (I(p)-1-i_p)/m;
                res(i_p+1,j_p+1,1) = V(i, j,1);
                res(i_p+1,j_p+1,2) = V(i, j,2);
                res(i_p+1,j_p+1,3) = V(i, j,3);
                p = p+1;
            end 
        end  
else 
        p=1;    
        for i = 1:m
            for j = 1:n
                i_p = mod(I(p)-1,m);
                j_p = (I(p)-1-i_p)/m;
                 res(i_p+1,j_p+1) = V(i, j);
                p = p+1;
            end 
        end
end

end