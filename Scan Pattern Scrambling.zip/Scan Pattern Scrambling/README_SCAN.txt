ALGO BASED REORDERING : 1-C, 2-Gamma, 3-L, 4-O, 5-pi, 6-U, 7-L1 , 8-L2, 
9-mini_p1, 10-mini_p2, 11-p1, 12-p2, 13-spiral1, 14-spiral

MATHS BASED REORDEING : Zigzag_forms : 15-zz1 -> 22-zz8


For 256bits -> 16x16
For 512bits -> 23x23
For 1024bits -> 32x32
For 2048bits -> 46x46 
For 4096bits -> 64x64


plotting_matrix_reordering
% fonction mila ampiana mode hafa (inverse sy opt)
% need  Plotting the patterns
% plotting_patterns(matrix)



% h1 = Shake256('hey', 64)
% [booleanValue, lengthsquare] = toboolean_pad(h1);
% res = parcours_C(reshape(booleanValue, lengthsquare,lengthsquare));
% hexValue = tohex(res(:))
% h2 = Shake256(hexValue, 64) 



getting_key()
% fonction mila ampiana mode hafa (inverse sy opt) + enregistrement de clé dans un fichiers
% need getting_key_with_parm(mode, choice, last_hash, length_bit) and provide next_hash
% https://www.developpez.net/forums/d1620631/environnements-developpement/matlab/ajouter-lignes-fichier-texte/


plotting_key
% copier le fichier toboolean.m

plotting_key_evaluation
% need file : key_entropy_binary.m  key_prob_bit_changement.m   key_prob_extreme.m  key_prob_proximity.m    key_correlation.m  coeff_correl.m     


For plotting key evaluation : 
>> plotting_key_evaluation(10, '-')

or
>> plotting_key_evaluation(10, ':')

or
>> plotting_key_evaluation(10, '--')

plotting_matrix_reordering
getting_key_with_parm
plotting_key_evaluation





