function res = parcours_L(a)

   % a = [1 2 3 4;5 6 7 8; 9 10 11 12;13 14 15 16;17 18 19 20;21 22 23 24]
    res = a;
   % b = [1 2 3 4 5 6;1 2 3 4 5 6;1 2 3 4 5 6;1 2 3 4 5 6]
     [H, W] = size(a);
     i_permute = 1;
     j_permute = 1;
     for l=1:W
        pivot = H-l+1;
        if(pivot > 1 )
                %parcours vertical of the L-parcours
               for j=1:pivot
                   %disp('VERTICAL');
                   %disp([i_permute, j_permute]);
                   %disp([j, l]);
                   %disp(j)
                   %disp(l);
                   %permutation of (j,l)
                   %affiche the permutation
                   %disp(i_permute);
                   %disp(j_permute);
                   res(i_permute,j_permute) = a(j,l);
                   %correction of permutation
                   j_permute = j_permute + 1;
                   if(j_permute == W+1)
                       i_permute = i_permute+1;
                       j_permute = 1;
                   end

                   
               end
                %parcours horizontal of the L-parcours
               if l+1 <= W
                      for k=l+1:W
                          % disp('HORIZONTAL')
                          % disp([pivot k])
                          %disp(pivot);
                          %disp(k);
                          %permutation of (pivot, k)
                          res(i_permute,j_permute) = a(pivot,k);

                                                    %affiche the permutation
                         % disp(i_permute);
                         % disp(j_permute);                         
                            %correction of permutation
                          j_permute = j_permute + 1;
                          if(j_permute == W+1)
                                i_permute = i_permute+1;
                                j_permute = 1;
                          end
                      end
              end
        else
          %else in the rest of the horizonal of L-parcours
            %disp(1);
            %disp(l);
            %permutation of (1,l)

                        %affiche the permutation
           % disp(i_permute);
           % disp(j_permute);
            %correction of permutation
            % alana    
            res(i_permute,j_permute) = a(1,l);

            j_permute = j_permute + 1;
             if(j_permute == W+1)
                 i_permute = i_permute+1;
                 j_permute = 1;
             end
            
        end
        
     end

end