%code by sitraka 13/03/2024
function res = parcours_pi1_inv(a)
   % a = [1 2 3 4;5 6 7 8; 9 10 11 12;13 14 15 16;17 18 19 20;21 22 23 24]
    res = a;
   % b = [1 2 3 4 5 6;7 8 9 10 11 12;13 14 15 16 17 18;19 20 21 22 23 24]
   %  d = [1 2 3 4 5;6 7 8 9 10;11 12 13 14 15;16 17 18 19 20;21 22 23 24 25]
   [H, W] = size(a);
   currentPointX  = 1;
   currentPointY  = 1;
   
%%%%%%   disp(W);
%%%%%%   disp(H);
   
   listpath = ones(1,W*H);
   mvt = 1;
   
   % disp('list path');   
   % disp(listpath);
   
   directionX = 1;
   directionY = 0;
   
   listpath(mvt) = (currentPointY-1)*W+(currentPointX-1)+1; 
  % while((currentPointX ~= W) || (currentPointY ~= H))
  while ( mvt ~= W*H)
        %let's calculate abs and ordinate of mvt
        x = mod(listpath(mvt)-1, W);
        y = floor((listpath(mvt)-1)/W);
        
        % disp('point');
        % disp(x);
        % disp(y);
        
        x = x+directionX;
        if((x >= W)||(x < 0))

            %correct abscisse
            x = x -directionX;
            %manipulation
            directionY = 1;
            directionX = directionX*(-1);
            y = y+directionY;
        else
           directionY = 0;
        end
        
        currentPointX = x+1;
        currentPointY = y+1;
   
         
        % disp('next point');
        % disp(x);
        % disp(y);
        mvt=mvt+1;
        listpath(mvt) = (currentPointY-1)*W+(currentPointX-1)+1; 

        % i get it : last changement
       % disp('list path');
       % disp(listpath);
       % demand = input("continue or not");
   end
   %listpath(mvt) = (H-1)*W+W; 
%%%%%%   disp('list path eto');
%%%%%%   disp(listpath);
   
   % for matlab , we need to inverse the coordinate
   for(mvt = 1:length(listpath))
       index = listpath(mvt);
       
       indexY = mod(mvt-1,W);
       indexX = floor((mvt-1)/W);
       
       PermuteIndexY = mod(index-1, W);
       PermuteIndexX = floor((index-1)/W);

       % disp('permute')
       % disp(indexX)
       % disp(indexY)
       
       
      % disp('with')
      % disp(PermuteIndexX)
      % disp(PermuteIndexY)
       
             
       res(PermuteIndexX+1, PermuteIndexY+1) =   a(indexX+1, indexY+1);
       
      % disp(res);
      % demand = input("continue or not");
       
   end
    
   
end
     