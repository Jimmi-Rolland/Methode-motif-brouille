function plotting_key
    mode = input('please enter the mode \n 0 for normal choice \n 1 for inverse mode \n 2 for opt mode\n');
    switch mode
        case 0
             disp('you select mode 0');
        
            length_key = 0;
            while((length_key~=256)&&(length_key~=512)&&(length_key~=1024)&&(length_key~=2048)&&(length_key~=4096))
                length_key = input('Please enter the key 256 or 512 or 1024 or 2048 or 4096 : \n');
            end
            
            % INITIALISATION PART 1 ;     
            last_hash = Shake256('hello world', length_key/4);
            number_fig = 1;
             
             figure
             % PLOTTING PART  1
             % parcoursC
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_C(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('C Path');

             % parcoursgamma
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_gamma(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Gamma Path');


             % parcoursL
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_L(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('L Path');

             
             % parcoursO
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_O(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('O Path');
             
             % parcourspi
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_pi(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Pi Path');

             % parcoursU
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_U(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('U Path');

             
             % parcoursL1
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_L1(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('L1 Path');
             

             % parcoursL2
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_L2(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('L2 Path');

             
             %%%%% PART 2 initialisation
             number_fig = 1;
             figure
             
             % PART2
             % parcours minpi1
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_min_pi1(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Min pi1 Path');

             % parcours minpi2
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_min_pi2(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Min pi2 Path');

             
             % parcours pi1
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_pi1(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Pi1 Path');


             % parcours pi2
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_pi2(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Pi2 Path');
             

             % parcours spiral1
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_spiral1(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Spiral1 Path');

             % parcours spiral2
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_spiral2(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Spiral2 Path');

             %%%%% PART 3 initialisation
             number_fig = 1;
             figure
             % PART 3
             %Parcours zigzag1
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag1(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag1 Path');
             

             %Parcours zigzag2
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag2(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag2 Path');

             
             %Parcours zigzag3
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag3(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag3 Path');
             
             
             %Parcours zigzag4
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag4(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag4 Path');
             
             %Parcours zigzag5
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag5(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag5 Path');

             %Parcours zigzag6
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag6(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag6 Path');


             %Parcours zigzag7
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag7(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag7 Path');
             
             
             %Parcours zigzag8
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag8(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag8 Path');

        case 1
             disp('you select mode 1');
            length_key = 0;
            while((length_key~=256)&&(length_key~=512)&&(length_key~=1024)&&(length_key~=2048)&&(length_key~=4096))
                length_key = input('Please enter the key 256 or 512 or 1024 or 2048 or 4096 : \n');
            end
            
            % INITIALISATION PART 1 ;     
            last_hash = Shake256('hello world', length_key/4);
            number_fig = 1;
             
             figure
             % PLOTTING PART  1
             % parcoursC
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_C_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('C Inv Path');

             % parcoursgamma
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_gamma_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Gamma Inv Path');


             % parcoursL
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_L_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('L Inv Path');

             
             % parcoursO
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_O_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('O Inv Path');
             
             % parcourspi
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_pi_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Pi Inv Path');

             % parcoursU
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_U_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('U Inv Path');

             
             % parcoursL1
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_L1_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('L1 Inv Path');
             

             % parcoursL2
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_L2_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('L2 Inv Path');

             
             %%%%% PART 2 initialisation
             number_fig = 1;
             figure
             
             % PART2
             % parcours minpi1
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_min_pi1_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Min pi1 Inv Path');

             % parcours minpi2
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_min_pi2_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Min pi2 Inv Path');

             
             % parcours pi1
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_pi1_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Pi1 Inv Path');


             % parcours pi2
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_pi2_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Pi2 Inv Path');
             

             % parcours spiral1
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_spiral1_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Spiral1 Inv Path');

             % parcours spiral2
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_spiral2_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('Spiral2 Inv Path');

             %%%%% PART 3 initialisation
             number_fig = 1;
             figure
             % PART 3
             %Parcours zigzag1
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag1_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag1 Inv Path');
             

             %Parcours zigzag2
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag2_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag2 Inv Path');

             
             %Parcours zigzag3
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag3_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag3 Inv Path');
             
             
             %Parcours zigzag4
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag4_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag4 Inv Path');
             
             %Parcours zigzag5
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag5_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag5 Inv Path');

             %Parcours zigzag6
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag6_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag6 Inv Path');


             %Parcours zigzag7
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag7_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag7 Inv Path');
             
             
             %Parcours zigzag8
             [booleanValue, lengthsquare] = toboolean_pad(last_hash);
             res = parcours_zigzag8_inv(reshape(booleanValue, lengthsquare,lengthsquare));
             hexValue = tohex(res(:));
             next_hash = Shake256(hexValue, length_key/4); 
             binhash = toboolean(next_hash);
             subplot(4,2,number_fig);
             number_fig = number_fig+1;
             stairs(binhash);
             ylim([0 1.2]);
             xlim([0 length_key+1]);
             title('zigzag8 Inv Path');
            
            
        case 2
             disp('you select mode 2');
            
            
    end


end