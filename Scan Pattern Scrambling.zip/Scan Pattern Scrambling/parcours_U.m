function res = parcours_U(a)

   % a = [1 2 3 4;5 6 7 8; 9 10 11 12;13 14 15 16;17 18 19 20;21 22 23 24]
    res = a;
   % b = [1 2 3 4 5 6;1 2 3 4 5 6;1 2 3 4 5 6;1 2 3 4 5 6]
    %  c = [1 2 3 4 5;6 7 8 9 10;11 12 13 14 15;16 17 18 19 20]
     [H, W] = size(a);
     i_permute = 1;
     j_permute = 1;
     
     pivot1_x = 1;
     pivot2_x = W;
     pivot1_y = H;
     pivot2_y = H;
     
     
     while(pivot2_y >=0)
        %premier horizontal de U
        if(pivot1_x <= pivot2_x)
            for j=1:pivot1_y
               x = j;
               y = pivot1_x;               
               res(i_permute, j_permute) = a(x,y);
                   j_permute = j_permute + 1;
                   if(j_permute == W+1)
                       i_permute = i_permute+1;
                       j_permute = 1;
                   end
            end
         end
         
        %premier vertical de U
        for i=pivot1_x+1:pivot2_x-1
            x = pivot1_y;
            y = i;
            res(i_permute, j_permute) = a(x,y);
                   j_permute = j_permute + 1;
                   if(j_permute == W+1)
                       i_permute = i_permute+1;
                       j_permute = 1;
                   end
        end
        
        %deuxieme ligne de U
        if(pivot2_x > pivot1_x)
            for j=pivot2_y:-1:1
            x = j;
            y = pivot2_x;      
            res(i_permute, j_permute) = a(x,y);
                   j_permute = j_permute + 1;
                   if(j_permute == W+1)
                       i_permute = i_permute+1;
                       j_permute = 1;
                   end

            end
        end
         pivot1_x = pivot1_x+1;
         pivot2_x  = pivot2_x -1;
         pivot1_y = pivot1_y-1;
         pivot2_y = pivot2_y-1;    
     end 
end
     