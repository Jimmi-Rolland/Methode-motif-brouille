%code by sitraka 13/03/2024
function res = parcours_pi2(a)
   % a = [1 2 3 4;5 6 7 8; 9 10 11 12;13 14 15 16;17 18 19 20;21 22 23 24]
    res = a;
   % b = [1 2 3 4 5 6;7 8 9 10 11 12;13 14 15 16 17 18;19 20 21 22 23 24]
   %  d = [1 2 3 4 5;6 7 8 9 10;11 12 13 14 15;16 17 18 19 20;21 22 23 24 25]
   [H, W] = size(a);
   currentPointX  = 1;
   currentPointY  = 1;
   
%%%   disp(W);
%%%   disp(H);
   
   listpath = ones(1,W*H);
   mvt = 1;
   
   % disp('list path');   
   % disp(listpath);
   
   directionX = 0;
   directionY = 1;
   
   listpath(mvt) = (currentPointY-1)*W+(currentPointX-1)+1; 
   %while((currentPointX ~= W) || (currentPointY ~= H))
   while ( mvt ~= W*H)
        %let's calculate abs and ordinate of mvt
        x = mod(listpath(mvt)-1, W);
        y = floor((listpath(mvt)-1)/W);
        
        % disp('point');
        % disp(x);
        % disp(y);
        
        y = y+directionY;
        if((y >= H)||(y < 0))

            %correct ordinate
            y = y -directionY;

            %manipulation
            directionX = 1;
            directionY = directionY*(-1);
            x = x+directionX;
        else
           directionX = 0;
        end
        
        currentPointX = x+1;
        currentPointY = y+1;
   
         
%%%         disp('next point');
%%%         disp(x);
%%%         disp(y);
        mvt=mvt+1;
        listpath(mvt) = (currentPointY-1)*W+(currentPointX-1)+1; 

        % get it : 
        % disp('list path');
        % disp(listpath);
        % demand = input("continue or not");
   end
   %disp('list path eto');
   %disp(listpath);
   
   % for matlab , we need to inverse the coordinate
   for(mvt = 1:length(listpath))
       index = listpath(mvt);
       
       indexY = mod(mvt-1,W);
       indexX = floor((mvt-1)/W);
       
       PermuteIndexY = mod(index-1, W);
       PermuteIndexX = floor((index-1)/W);

       % disp('permute')
       % disp(indexX)
       % disp(indexY)
       
       
      % disp('with')
      % disp(PermuteIndexX)
      % disp(PermuteIndexY)
       
             
       res(indexX+1, indexY+1) =   a(PermuteIndexX+1, PermuteIndexY+1);
       
      % disp(res);
      % demand = input("continue or not");
       
   end
   
   
   
   
end
     