function plotting_matrix_reordering()

    length_key = 0;
    while((length_key~=256)&&(length_key~=512)&&(length_key~=1024)&&(length_key~=2048)&&(length_key~=4096))
        length_key = input('Please enter the key 256 or 512 or 1024 or 2048 or 4096 : ');
    end
    
    switch  length_key
        case 256
            W = 16;
            H = 16;
            
        case 512  
            W = 23;
            H = 23;
        case 1024
            W = 32;
            H = 32;
        case 2048 
            W = 46;
            H = 46;
        case 4096 
            W = 64;
            H = 64;
    end
    
% fill the matrix 1 2 3 ...
p = 1
for i = 1:W
    for j = 1:H
        matrix(i,j) = p;
        p = p+1;
    end
end

finished = false;
while ~finished
	mode = input('Enter the mode : \n 0  : for normal mode \n 1 : for inverse mode\n');
	choice = input('Enter the choice : \n1  : C_Path         2  : Gamma_Path     3  : L_Path         4  : O_Path         \n5  : pi_Path        6  : U_Path         7  : L1_Path        8  : L2_Path   \n9  : mini_p1_Path   10 : mini_pi2_Path  11 : pi1_Path       12 : pi2_Path        \n13 : spiral1_Path   14 : spiral2_Path   15 : zigzag1_Path   16 : zigzag2_Path   \n17 : zigzag3_Path   18 : zigzag4_Path   19 : zigzag5_Path   20 : zigzag6_Path    \n21 : zigzag7_Path   22 : zigzag8_Path\n');
	% mode 0
    if mode == 0
		disp('normal mode');
	    switch choice
        case 1
			disp(matrix);
			matrix_C = parcours_C(matrix);
			disp('matrix C after the C path');
			disp(matrix_C);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_C)
            plotting_patterns(matrix_C);
        case 2  
			disp(matrix);
			matrix_Gamma = parcours_gamma(matrix);
			disp('matrix Gamma after the Gamma path');
			disp(matrix_Gamma);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_Gamma)
            plotting_patterns(matrix_Gamma);

        case 3
			disp(matrix);
			matrix_L = parcours_L(matrix);
			disp('matrix L after the L path');
			disp(matrix_L);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_L)
            plotting_patterns(matrix_L);

        case 4 
			disp(matrix);
			matrix_O = parcours_O(matrix);
			disp('matrix O after the O path');
			disp(matrix_O);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_O)
            plotting_patterns(matrix_O);

         case 5 
			disp(matrix);
			matrix_pi = parcours_pi(matrix);
			disp('matrix pi after the pi path');
			disp(matrix_pi);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_pi)
            plotting_patterns(matrix_pi);
        case 6 
			disp(matrix);
			matrix_U = parcours_U(matrix);
			disp('matrix U after the U path');
			disp(matrix_U);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_U)
            plotting_patterns(matrix_U);
        case 7 
			disp(matrix);
			matrix_L1 = parcours_L1(matrix);
			disp('matrix L1 after the L1 path');
			disp(matrix_L1);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_L1)
            plotting_patterns(matrix_L1);

        case 8 
			disp(matrix);
			matrix_L2 = parcours_L2(matrix);
			disp('matrix L2_Path after the L2 path');
			disp(matrix_L2);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_L2)
            plotting_patterns(matrix_L2);

         case 9 
			disp(matrix);
			matrix_min_pi1 = parcours_min_pi1(matrix);
			disp('matrix min_pi1 Path after the min_pi1 path');
			disp(matrix_min_pi1);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_min_pi1)
            plotting_patterns(matrix_min_pi1);
            
        case 10
			disp(matrix);
			matrix_min_pi2 = parcours_min_pi2(matrix);
			disp('matrix min_pi2 Path after the min_pi2 path');
			disp(matrix_min_pi2);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_min_pi2)
            plotting_patterns(matrix_min_pi2);

        case 11
			disp(matrix);
			matrix_pi1 = parcours_pi1(matrix);
			disp('matrix pi1 Path after the pi1 path');
			disp(matrix_pi1);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_pi1)
            plotting_patterns(matrix_pi1);

            
        case 12
			disp(matrix);
			matrix_pi2 = parcours_pi2(matrix);
			disp('matrix pi2 Path after the pi2 path');
			disp(matrix_pi2);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_pi2)
            plotting_patterns(matrix_pi2);


       case 13
			disp(matrix);
			matrix_spiral1 = parcours_spiral1(matrix);
			disp('matrix spiral1 Path after the spiral1 path');
			disp(matrix_spiral1);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_spiral1)
            plotting_patterns(matrix_spiral1);
            
        case 14
			disp(matrix);
			matrix_spiral2 = parcours_spiral2(matrix);
			disp('matrix spiral2 Path after the spiral2 path');
			disp(matrix_spiral2);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_spiral2)
            plotting_patterns(matrix_spiral2);
         
        case 15 
			disp(matrix);
			matrix_ZZ1 = parcours_zigzag1(matrix);
			disp('matrix ZZ1 after the zigzag1 path');
			disp(matrix_ZZ1);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ1)
            plotting_patterns(matrix_ZZ1);
         

        case 16 
			disp(matrix);
			matrix_ZZ2 = parcours_zigzag2(matrix);
			disp('matrix ZZ2 after the zigzag2 path');
			disp(matrix_ZZ2);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ2)
            plotting_patterns(matrix_ZZ2);
         

        case 17 
			disp(matrix);
			matrix_ZZ3 = parcours_zigzag3(matrix);
			disp('matrix ZZ3 after the zigzag3 path');
			disp(matrix_ZZ3);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ3)
            plotting_patterns(matrix_ZZ3);
  
        case 18 
			disp(matrix);
			matrix_ZZ4 = parcours_zigzag4(matrix);
			disp('matrix ZZ4 after the zigzag4 path');
			disp(matrix_ZZ4);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ4)
            plotting_patterns(matrix_ZZ4);
  

        case 19 
			disp(matrix);
			matrix_ZZ5 = parcours_zigzag5(matrix);
			disp('matrix ZZ5 after the zigzag5 path');
			disp(matrix_ZZ5);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ5)
            plotting_patterns(matrix_ZZ5);
  
        case 20 
			disp(matrix);
			matrix_ZZ6 = parcours_zigzag6(matrix);
			disp('matrix ZZ6 after the zigzag6 path');
			disp(matrix_ZZ6);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ6)
            plotting_patterns(matrix_ZZ6);
  

        case 21 
			disp(matrix);
			matrix_ZZ7 = parcours_zigzag7(matrix);
			disp('matrix ZZ7 after the zigzag7 path');
			disp(matrix_ZZ7);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ7)
            plotting_patterns(matrix_ZZ7);
  

        case 22 
			disp(matrix);
			matrix_ZZ8 = parcours_zigzag8(matrix);
			disp('matrix ZZ8 after the zigzag8 path');
			disp(matrix_ZZ8);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ8)
            plotting_patterns(matrix_ZZ8);  
        end
    end    


	% mode 1
    if mode == 1
		disp('inverse mode');
	    switch choice
        case 1
			disp(matrix);
			matrix_C = parcours_C_inv(matrix);
			disp('matrix C after the C_Inv path');
			disp(matrix_C);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_C)
            plotting_patterns(matrix_C);
        case 2  
			disp(matrix);
			matrix_Gamma = parcours_gamma_inv(matrix);
			disp('matrix Gamma after the Gamma_Inv path');
			disp(matrix_Gamma);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_Gamma)
            plotting_patterns(matrix_Gamma);

        case 3
			disp(matrix);
			matrix_L = parcours_L_inv(matrix);
			disp('matrix L after the L_Inv path');
			disp(matrix_L);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_L)
            plotting_patterns(matrix_L);

        case 4 
			disp(matrix);
			matrix_O = parcours_O_inv(matrix);
			disp('matrix O after the O_Inv path');
			disp(matrix_O);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_O)
            plotting_patterns(matrix_O);

         case 5 
			disp(matrix);
			matrix_pi = parcours_pi_inv(matrix);
			disp('matrix pi after the pi_Inv path');
			disp(matrix_pi);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_pi)
            plotting_patterns(matrix_pi);
        case 6 
			disp(matrix);
			matrix_U = parcours_U_inv(matrix);
			disp('matrix U after the U_Inv path');
			disp(matrix_U);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_U)
            plotting_patterns(matrix_U);
        case 7 
			disp(matrix);
			matrix_L1 = parcours_L1_inv(matrix);
			disp('matrix L1 after the L1_Inv path');
			disp(matrix_L1);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_L1)
            plotting_patterns(matrix_L1);

        case 8 
			disp(matrix);
			matrix_L2 = parcours_L2_inv(matrix);
			disp('matrix L2_Path after the L2_Inv path');
			disp(matrix_L2);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_L2)
            plotting_patterns(matrix_L2);

         case 9 
			disp(matrix);
			matrix_min_pi1 = parcours_min_pi1_inv(matrix);
			disp('matrix min_pi1 Path after the min_pi1_Inv path');
			disp(matrix_min_pi1);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_min_pi1)
            plotting_patterns(matrix_min_pi1);
            
        case 10
			disp(matrix);
			matrix_min_pi2 = parcours_min_pi2_inv(matrix);
			disp('matrix min_pi2 Path after the min_pi2_Inv path');
			disp(matrix_min_pi2);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_min_pi2)
            plotting_patterns(matrix_min_pi2);

        case 11
			disp(matrix);
			matrix_pi1 = parcours_pi1_inv(matrix);
			disp('matrix pi1 Path after the pi1_Inv path');
			disp(matrix_pi1);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_pi1)
            plotting_patterns(matrix_pi1);

            
        case 12
			disp(matrix);
			matrix_pi2 = parcours_pi2_inv(matrix);
			disp('matrix pi2 Path after the pi2_Inv path');
			disp(matrix_pi2);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_pi2)
            plotting_patterns(matrix_pi2);


       case 13
			disp(matrix);
			matrix_spiral1 = parcours_spiral1_inv(matrix);
			disp('matrix spiral1 Path after the spiral1_Inv path');
			disp(matrix_spiral1);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_spiral1)
            plotting_patterns(matrix_spiral1);
            
        case 14
			disp(matrix);
			matrix_spiral2 = parcours_spiral2_inv(matrix);
			disp('matrix spiral2 Path after the spiral2_Inv path');
			disp(matrix_spiral2);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_spiral2)
            plotting_patterns(matrix_spiral2);
         
        case 15 
			disp(matrix);
			matrix_ZZ1 = parcours_zigzag1_inv(matrix);
			disp('matrix ZZ1 after the zigzag1_Inv path');
			disp(matrix_ZZ1);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ1)
            plotting_patterns(matrix_ZZ1);
         

        case 16 
			disp(matrix);
			matrix_ZZ2 = parcours_zigzag2_inv(matrix);
			disp('matrix ZZ2 after the zigzag2_Inv path');
			disp(matrix_ZZ2);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ2)
            plotting_patterns(matrix_ZZ2);
         

        case 17 
			disp(matrix);
			matrix_ZZ3 = parcours_zigzag3_inv(matrix);
			disp('matrix ZZ3 after the zigzag3_Inv path');
			disp(matrix_ZZ3);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ3)
            plotting_patterns(matrix_ZZ3);
  
        case 18 
			disp(matrix);
			matrix_ZZ4 = parcours_zigzag4_inv(matrix);
			disp('matrix ZZ4 after the zigzag4_Inv path');
			disp(matrix_ZZ4);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ4)
            plotting_patterns(matrix_ZZ4);
  

        case 19 
			disp(matrix);
			matrix_ZZ5 = parcours_zigzag5_inv(matrix);
			disp('matrix ZZ5 after the zigzag5_Inv path');
			disp(matrix_ZZ5);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ5)
            plotting_patterns(matrix_ZZ5);
  
        case 20 
			disp(matrix);
			matrix_ZZ6 = parcours_zigzag6_inv(matrix);
			disp('matrix ZZ6 after the zigzag6_Inv path');
			disp(matrix_ZZ6);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ6)
            plotting_patterns(matrix_ZZ6);
  

        case 21 
			disp(matrix);
			matrix_ZZ7 = parcours_zigzag7_inv(matrix);
			disp('matrix ZZ7 after the zigzag7_Inv path');
			disp(matrix_ZZ7);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ7)
            plotting_patterns(matrix_ZZ7);
  

        case 22 
			disp(matrix);
			matrix_ZZ8 = parcours_zigzag8_inv(matrix);
			disp('matrix ZZ8 after the zigzag8_Inv path');
			disp(matrix_ZZ8);
			[HopPointNumber, LinearityLineNumber] = evaluate_linearity_patterns(matrix, matrix_ZZ8)
            plotting_patterns(matrix_ZZ8);  
        end

		
    end 

end 

end