function res = parcours_C_inv(a)

   % a = [1 2 3 4;5 6 7 8; 9 10 11 12;13 14 15 16;17 18 19 20;21 22 23 24]
    res = a;
   % b = [1 2 3 4 5 6;7 8 9 10 11 12;13 14 15 16 17 18;19 20 21 22 23 24]
   %  d = [1 2 3 4 5;6 7 8 9 10;11 12 13 14 15;16 17 18 19 20;21 22 23 24 25]
     [H, W,k] = size(a);
     i_permute = 1;
     j_permute = 1;
     
     pivot1_x = 1;
     pivot2_x = W;
     pivot1_y = H;
     pivot2_y = H;
     
     
     while(pivot2_y >=0)
        % diag 1 
        if(pivot1_x <= pivot1_y)
            for i=W:-1:pivot1_x
                y = i;
                x = pivot1_x;
                if(k == 1)
                    res(x, y) = a(i_permute,j_permute);
                else
                    res(x, y,1) = a(i_permute,j_permute,1);
                    res(x, y,2) = a(i_permute,j_permute,2);
                    res(x, y,3) = a(i_permute,j_permute,3);
                end
                   j_permute = j_permute + 1;
                   if(j_permute == W+1)
                       i_permute = i_permute+1;
                       j_permute = 1;
                   end
            end
        end
        
        %ligne
        for i=pivot1_x+1:pivot2_y-1
            x = i;
            y = pivot1_x;
                if(k == 1)
                    res(x, y) = a(i_permute,j_permute);
                else
                    res(x, y,1) = a(i_permute,j_permute,1);
                    res(x, y,2) = a(i_permute,j_permute,2);
                    res(x, y,3) = a(i_permute,j_permute,3);
                end
            j_permute = j_permute + 1;
                   if(j_permute == W+1)
                       i_permute = i_permute+1;
                       j_permute = 1;
                   end

        end
            
        %diag 2
        if(pivot1_x < pivot1_y)
            for i=pivot1_x:W
                %disp(pivot1_y)
                %disp(i);
                x = pivot1_y;
                y = i;
                if(k == 1)
                    res(x, y) = a(i_permute,j_permute);
                else
                    res(x, y,1) = a(i_permute,j_permute,1);
                    res(x, y,2) = a(i_permute,j_permute,2);
                    res(x, y,3) = a(i_permute,j_permute,3);
                end
                
                j_permute = j_permute + 1;
                   if(j_permute == W+1)
                       i_permute = i_permute+1;
                       j_permute = 1;
                   end
            end
        end
         pivot1_x = pivot1_x+1;
         pivot2_x  = pivot2_x -1;
         pivot1_y = pivot1_y-1;
         pivot2_y = pivot2_y-1;
     end
     
end
     