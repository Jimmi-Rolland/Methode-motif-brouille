function getting_key()
    % Demander à l'utilisateur le nombre de clés à générer
    nb_key = input('Please enter the number of keys to generate \n');
    
    % Initialiser la longueur de la clé
    length_key = 0;
    
    % Boucle pour s'assurer que la longueur de la clé est correcte
    while((length_key~=256)&&(length_key~=512)&&(length_key~=1024)&&(length_key~=2048)&&(length_key~=4096))
        length_key = input('Please enter the key length (256, 512, 1024, 2048, 4096) : \n');
    end
    
    % Demander à l'utilisateur le texte à utiliser comme base
    base_text = input('Please enter the base text for hashing: \n', 's');
    
    % Initialiser l'état de la boucle principale
    finished = false;
    
    while ~finished
        % Demander à l'utilisateur de choisir le mode
        mode = input('Enter the mode : \n 0  : for normal mode \n 1 : for inverse mode\n');
        
        % Demander à l'utilisateur de choisir l'option de chemin
        choice = input('Enter the choice : \n1  : C_Path         2  : Gamma_Path     3  : L_Path         4  : O_Path         \n5  : pi_Path        6  : U_Path         7  : L1_Path        8  : L2_Path   \n9  : mini_p1_Path   10 : mini_pi2_Path  11 : pi1_Path       12 : pi2_Path        \n13 : spiral1_Path   14 : spiral2_Path   15 : zigzag1_Path   16 : zigzag2_Path   \n17 : zigzag3_Path   18 : zigzag4_Path   19 : zigzag5_Path   20 : zigzag6_Path    \n21 : zigzag7_Path   22 : zigzag8_Path\n');
        
        % Calculer le premier hash avec le texte de base
        last_hash = Shake256(base_text, length_key/4);
        
        % Boucle pour générer et afficher les clés
        for i = 1 : nb_key
            next_hash = getting_key_with_parm(mode, choice, last_hash, length_key);
          % Séparer la chaîne en deux parties égales
            half_length = length(last_hash) / 2;
            part1 = last_hash(1:half_length);
            part2 = last_hash(half_length+1:end);
            
            last_hash = next_hash;
          
         %affiche les resultats
            fprintf('Part 1: %s\n', part1);
            fprintf('Part 2: %s\n', part2);
            
        end
        
     
            
        
    end

