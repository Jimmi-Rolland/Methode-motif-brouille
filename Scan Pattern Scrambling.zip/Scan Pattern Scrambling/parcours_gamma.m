function res = parcours_gamma(a)
%tic
   % a = [1 2 3 4;5 6 7 8; 9 10 11 12;13 14 15 16;17 18 19 20;21 22 23 24]
    res = a;
   % b = [1 2 3 4 5 6;7 8 9 10 11 12;13 14 15 16 17 18;19 20 21 22 23 24]
     [H, W,K] = size(a);
     i_permute = 1;
     j_permute = 1;
     for l=1:H     
        pivot = W-l+1;
        %parcours horizontal of gamma-parcours
        if(pivot > 1 )
               for j=1:pivot
                   res(i_permute,j_permute) = a(l,j);
                   %correction of permutation
                   j_permute = j_permute + 1;
                   if(j_permute == W+1)
                       i_permute = i_permute+1;
                       j_permute = 1;
                   end                   
               end
     
               %parcours vertical of the gamma-parcours
               if l+1 <= H
                      for k=l+1:H
                          res(i_permute,j_permute) = a(k,pivot);
                          j_permute = j_permute + 1;
                          if(j_permute == W+1)
                                i_permute = i_permute+1;
                                j_permute = 1;
                          end
                      end
               end
        else
          %else in the rest of the horizonal of L-parcours
            res(i_permute,j_permute) = a(l,1);
            %correction of permutation
            j_permute = j_permute + 1;
            if(j_permute == W+1)
                 i_permute = i_permute+1;
                 j_permute = 1;
            end
        end
     end
%toc
end