function  next_hash = getting_key_with_parm(mode, choice, last_hash, length_bit)
        next_hash = '0';
		if mode == 0
    		% disp('normal mode');
            switch choice
                case 1
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_C(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
                case 2  
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_gamma(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 3
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_L(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
                
                case 4 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_O(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                 case 5 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_pi(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
                case 6 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_U(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
                case 7 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_L1(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
                case 8 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_L2(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                 case 9 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_min_pi1(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 10
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_min_pi2(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 11
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_pi1(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 12
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_pi2(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

               case 13
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_spiral1(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 14
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_spiral2(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 15 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag1(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 16 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag2(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 


                case 17 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag3(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 18 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag4(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 19 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag5(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
                case 20 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag6(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 21 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag7(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 


                case 22 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag8(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
            end
		
    	end

        if mode == 1
    		% disp('normal mode');
            switch choice
                case 1
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_C_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
                case 2  
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_gamma_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 3
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_L_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
                
                case 4 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_O_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                 case 5 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_pi_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
                case 6 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_U_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
                case 7 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_L1_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
                case 8 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_L2_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                 case 9 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_min_pi1_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 10
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_min_pi2_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 11
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_pi1_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 12
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_pi2_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

               case 13
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_spiral1_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 14
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_spiral2_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 15 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag1_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 16 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag2_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 


                case 17 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag3_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 18 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag4_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 19 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag5_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
                case 20 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag6_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 

                case 21 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag7_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 


                case 22 
                    [booleanValue, lengthsquare] = toboolean_pad(last_hash);
                    res = parcours_zigzag8_inv(reshape(booleanValue, lengthsquare,lengthsquare));
                    hexValue = tohex(res(:));
                    next_hash = Shake256(hexValue, length_bit/4); 
            end
		
    	end

    
    
end