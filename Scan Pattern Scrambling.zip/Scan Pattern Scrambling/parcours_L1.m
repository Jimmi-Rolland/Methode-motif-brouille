% code by sitraka 13/03/2024
% just change direction and collision
% add two points for non permanent direction

function res = parcours_L1(a)
    % a = [1 2 3 4;5 6 7 8; 9 10 11 12;13 14 15 16;17 18 19 20;21 22 23 24]
    res = a;
    % b = [1 2 3 4 5 6;7 8 9 10 11 12;13 14 15 16 17 18;19 20 21 22 23 24]
    %  d = [1 2 3 4 5;6 7 8 9 10;11 12 13 14 15;16 17 18 19 20;21 22 23 24 25]
    [H, W] = size(a);
    currentPointX  = 1;
    currentPointY  = 1;
   
    % disp(W);
    % disp(H);
   
    listpath = ones(1,W*H);
    mvt = 1;
   
    % disp('list path');   
    % disp(listpath);
   
    directionX = 0;
    directionY = 1;
   
    dynW = W;
    dynH = H;
    dynX0 = 0;
    dynY0 = 0;
   
    listpath(mvt) = (currentPointY-1)*W+(currentPointX-1)+1; 
    %(currentPointX ~= W) || (currentPointY ~= H)||
    while(mvt ~= W*H)
        %let's calculate abs and ordinate of mvt
        x = mod(listpath(mvt)-1, W);
        y = floor((listpath(mvt)-1)/W);
        
        % disp('point');
        % disp(x);
        % disp(y);
        
        % disp('dynX0');
        % disp(dynX0);
        % disp('dynW');
        % disp(dynW);
               
        % disp('dynY0');
        % disp(dynY0);
        % disp('dynH');
        % disp(dynH);
          
        x = x+directionX;        
        y = y+directionY;

        % FIRST COLLISION
        if(y>= dynH)
             % disp('COLISSION Y H')
             dynX0 = dynX0+1;
           
             % disp('mihena dinW');
             % disp(dynW);
                
              x = x-directionX;        
              y = y-directionY;

              % collision1
              if ( x < dynW)
                directionX = 1;
                directionY = 0;  
              end
              
               x = x+directionX;        
               y = y+directionY;
               
               % disp('apres midofotra');
               % disp('dynX0');
               % disp(dynX0);
               % disp('dynW');
               % disp(dynW);
               
               % disp('dynY0');
               % disp(dynY0);
               % disp('dynH');
               % disp(dynH);
        
        end
        
        % FOURTH COLLISION
        if(y<dynY0)
            dynX0 = dynX0+1;   
            % disp('COLLISION Y 0');

            x = x-directionX;        
            y = y-directionY;
            
            if ( x < dynW)
                directionX = 1;
                directionY = 0;
            end
            
            x = x+directionX;
            y = y+directionY;
               
            % disp('dynX0');
            % disp(dynX0);
            % disp('dynW');
            % disp(dynW);
               
            % disp('dynY0');
            % disp(dynY0);
            % disp('dynH');
            % disp(dynH);
            
               
            % INSERER OTHER COEFFICIENT
               
            if (mvt < W*H)
                currentPointX = x+1;
                currentPointY = y+1;
         
                % disp('next point');
                % disp(x);
                % disp(y);
                mvt=mvt+1;
                listpath(mvt) = (currentPointY-1)*W+(currentPointX-1)+1; 

                if( y < dynH)  %%% modified
                    directionX = 0;
                    directionY = 1;        
                end
                x = x+directionX;        
                y = y+directionY;      

            end   
         end
 
          % SECOND COLLISION
          if(x>=dynW)
                dynH = dynH-1;
                % disp('collision X H')
         
                x = x-directionX;        
                y = y-directionY;

                % manipulation
                % collision2
                if (y >= dynY0)
                    directionX = 0;
                    directionY = -1;
                end
                
                x = x+directionX;        
                y = y+directionY;      
                    
               % disp('apres midofotra');
               % disp('dynX0');
               % disp(dynX0);
               % disp('dynW');
               % disp(dynW);
               
               % disp('dynY0');
               % disp(dynY0);
               % disp('dynH');
               % disp(dynH);


               % INSERT THE SECOND COEFFICIENT
               if ( mvt < W*H)
                    currentPointX = x+1;
                    currentPointY = y+1;
         
                    % disp('next point');
                    % disp(x);
                    % disp(y);
                    mvt=mvt+1;
                    listpath(mvt) = (currentPointY-1)*W+(currentPointX-1)+1; 

                    if( y >= dynY0)
                         directionX = -1;
                         directionY = 0;       
                    end
                    
                    x = x+directionX;        
                    y = y+directionY;      
               
               end
          end
          
          
         % THIRD COLLISION
         if(x < dynX0)
                dynH = dynH-1;   
                %dynX0 = dynX0-1; % modified
                % disp('COLLISION X 0');
                x = x-directionX;        
                y = y-directionY;
                
                % collision 2
                if( y >= dynY0)
                    directionX = 0;
                    directionY = -1;
                end
                
                x = x+directionX;
                y = y+directionY;
                        
               % disp('apres midofotra');
               % disp('dynX0');
               % disp(dynX0);
               % disp('dynW');
               % disp(dynW);
               
               % disp('dynY0');
               % disp(dynY0);
               % disp('dynH');
               % disp(dynH);

         end
        
        if(mvt < W*H)
        
            % disp('directionX')
            % disp(directionX)
            % disp('directionY')
            % disp(directionY)        
            
            currentPointX = x+1;
            currentPointY = y+1;
    
            % disp('next point');
            % disp(x);
            % disp(y);
            mvt=mvt+1;
            listpath(mvt) = (currentPointY-1)*W+(currentPointX-1)+1; 

            %%%%%%%%%%%%%%%%%%% STEP BY STEP, JUST UNCOMMENT %%%%%%%%%%%%%%%%%%
            % disp('list path');
            % disp(listpath);
            
        end
        %%%%%%%%%%%%%%%%%%% STEP BY STEP, JUST UNCOMMENT %%%%%%%%%%%%%%%%%% 
        %demand = input("continue or not");
   end
   
   % for matlab , we need to inverse the coordinate
   for(mvt = 1:length(listpath))
       index = listpath(mvt);
       
       indexY = mod(mvt-1,W);
       indexX = floor((mvt-1)/W);
       
       PermuteIndexY = mod(index-1, W);
       PermuteIndexX = floor((index-1)/W);

       % disp('permute')
       % disp(indexX)
       % disp(indexY)
              
      % disp('with')
      % disp(PermuteIndexX)
      % disp(PermuteIndexY)
       
             
       res(indexX+1, indexY+1) =   a(PermuteIndexX+1, PermuteIndexY+1);
       
      % disp(res);
      % demand = input("continue or not");
       
   end
   
   
end
     